var searchData=
[
  ['carregarantenasdoficheiro_0',['CarregarAntenasDoFicheiro',['../antenas_8c.html#a6712a3faa6702e6373561a397f1809b7',1,'antenas.c']]],
  ['criaantena_1',['criaantena',['../antenas_8c.html#aebea1184fdbb3fa31bba3fc9c04b41bd',1,'CriaAntena(char freq, int linha, int coluna):&#160;antenas.c'],['../antenas_8h.html#a0cddd59c73ccb91cdbfaf548746e0d9e',1,'CriaAntena(char frequencia, int linha, int coluna):&#160;antenas.c']]]
];
